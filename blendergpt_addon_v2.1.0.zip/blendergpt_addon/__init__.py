bl_info = {
    "name": "BlenderGPT Addon",
    "author": "BlenderGPT",
    "version": (2, 1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > BlenderGPT",
    "description": "Connect Blender to BlenderGPT for scene editing and imports.",
    "category": "3D View",
}

import base64
import hashlib
import io
import json
import os
import queue
import socket
import ssl
import struct
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
import uuid
import webbrowser
from contextlib import redirect_stdout

import addon_utils
import bpy

# Addon HTTP calls hit the webapp (sign-in + fallback polling). The webapp
# proxies /poll and /respond to the droplet via the Cloudflare Worker, so
# this single host covers both paths. WebSocket traffic goes directly to
# the droplet via _derive_ws_url.
BRIDGE_SERVER_URLS = (
    "http://localhost:3000",
    "https://blendergpt.org",
)


def _bridge_error_lines(error_text, max_line_length=72, max_lines=3):
    text = (error_text or "").strip()
    if not text:
        return []

    segments = [segment.strip() for segment in text.split(" | ") if segment.strip()]
    lines = []
    for segment in segments:
        remaining = segment
        while remaining and len(lines) < max_lines:
            if len(remaining) <= max_line_length:
                lines.append(remaining)
                remaining = ""
                continue

            split_at = remaining.rfind(" ", 0, max_line_length)
            if split_at <= 0:
                split_at = max_line_length
            lines.append(remaining[:split_at].strip())
            remaining = remaining[split_at:].strip()

        if len(lines) >= max_lines:
            break

    if not lines:
        return []

    if len(" ".join(segments)) > sum(len(line) for line in lines):
        lines[-1] = lines[-1].rstrip(".") + "..."

    return lines[:max_lines]


class CommandTask:
    def __init__(self, command_type, params):
        self.command_type = command_type
        self.params = params or {}
        self.done = threading.Event()
        self.response = {"status": "error", "message": "Unprocessed command"}


def _get_addon_preferences():
    try:
        addon = bpy.context.preferences.addons.get(__name__)
        if addon:
            return addon.preferences
    except Exception:
        pass
    return None


class BlenderGPTServer:
    def __init__(self, host="127.0.0.1", port=9876):
        self.host = host
        self.port = port
        self.running = False
        self.server_socket = None
        self.server_thread = None
        self.command_queue = queue.Queue()
        self.latest_assistant_mutation = None
        self.processor_registered = False

    def ensure_command_processor(self):
        if self.processor_registered:
            return
        bpy.app.timers.register(self._process_pending_commands, first_interval=0.05)
        self.processor_registered = True

    def start(self):
        if self.running:
            self.ensure_command_processor()
            return
        self.running = True
        self.server_thread = threading.Thread(target=self._run_server, daemon=True)
        self.server_thread.start()
        self.ensure_command_processor()
        print(f"[BlenderGPT] TCP server starting on {self.host}:{self.port}")

    def stop(self):
        if not self.running:
            return
        self.running = False
        try:
            if self.server_socket:
                self.server_socket.close()
        except Exception:
            pass
        self.server_socket = None
        print("[BlenderGPT] TCP server stopped")

    def _run_server(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.listen(8)
            sock.settimeout(1.0)
            self.server_socket = sock
            print(f"[BlenderGPT] Listening on {self.host}:{self.port}")

            while self.running:
                try:
                    conn, addr = sock.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break

                thread = threading.Thread(
                    target=self._handle_client, args=(conn, addr), daemon=True
                )
                thread.start()
        except Exception as exc:
            print(f"[BlenderGPT] Server error: {exc}")
            traceback.print_exc()
            self.running = False
        finally:
            try:
                if self.server_socket:
                    self.server_socket.close()
            except Exception:
                pass
            self.server_socket = None

    def _handle_client(self, conn, addr):
        with conn:
            conn.settimeout(60.0)
            buffer = ""
            while self.running:
                try:
                    data = conn.recv(4096)
                    if not data:
                        return
                    buffer += data.decode("utf-8")
                except socket.timeout:
                    return
                except Exception:
                    return

                while "\n" in buffer:
                    raw, buffer = buffer.split("\n", 1)
                    raw = raw.strip()
                    if not raw:
                        continue

                    try:
                        payload = json.loads(raw)
                    except Exception:
                        response = {"status": "error", "message": "Invalid JSON"}
                        conn.sendall((json.dumps(response) + "\n").encode("utf-8"))
                        continue

                    command_type = payload.get("type")
                    params = payload.get("params", {})
                    task = CommandTask(command_type, params)
                    self.command_queue.put(task)

                    if not task.done.wait(timeout=60):
                        response = {
                            "status": "error",
                            "message": "Command timed out in Blender main thread",
                        }
                    else:
                        response = task.response

                    try:
                        conn.sendall((json.dumps(response) + "\n").encode("utf-8"))
                    except Exception:
                        return

    def _process_pending_commands(self):
        while True:
            try:
                task = self.command_queue.get_nowait()
            except queue.Empty:
                break

            try:
                task.response = self._execute_command(task.command_type, task.params)
            except Exception as exc:
                task.response = {
                    "status": "error",
                    "message": f"Command execution failed: {str(exc)}",
                }
                traceback.print_exc()
            finally:
                task.done.set()

        if self.running or not self.command_queue.empty():
            return 0.05
        self.processor_registered = False
        return None

    def _execute_command(self, command_type, params):
        if command_type == "ping":
            return {"status": "ok", "result": "pong"}
        if command_type == "execute_code":
            return self._execute_code(params)
        if command_type == "get_scene_info":
            return self._get_scene_info()
        if command_type == "get_viewport_screenshot":
            return self._get_viewport_screenshot()
        if command_type == "import_mesh":
            return self._import_mesh(params)
        if command_type == "import_mesh_batch":
            return self._import_mesh_batch(params)
        if command_type == "assistant_undo_last":
            return self._assistant_undo_last(params)
        return {"status": "error", "message": f"Unknown command type: {command_type}"}

    def _build_undo_metadata(self, kind, label):
        token = f"assistant_{uuid.uuid4().hex}"
        metadata = {
            "undo_token": token,
            "undo_label": label,
            "undo_kind": kind,
            "undoable": True,
        }
        self.latest_assistant_mutation = metadata
        return metadata

    def _clear_undo_metadata(self, token=None):
        if token and self.latest_assistant_mutation:
            if self.latest_assistant_mutation.get("undo_token") != token:
                return
        self.latest_assistant_mutation = None

    def _assistant_undo_last(self, params):
        expected_token = str(params.get("undo_token") or "").strip()
        latest = self.latest_assistant_mutation
        if not latest:
            return {
                "status": "error",
                "message": "There is no recent assistant action available to undo.",
            }

        latest_token = str(latest.get("undo_token") or "").strip()
        if expected_token and latest_token and expected_token != latest_token:
            return {
                "status": "error",
                "message": "A newer assistant action already changed the Blender scene.",
            }

        try:
            bpy.ops.ed.undo()
        except Exception:
            return {
                "status": "error",
                "message": traceback.format_exc(),
            }

        self._clear_undo_metadata(latest_token)
        return {
            "status": "ok",
            "result": {
                "undone": True,
                "undo_token": latest_token,
                "undo_label": latest.get("undo_label"),
                "undo_kind": latest.get("undo_kind"),
            },
        }

    def _ensure_gltf_importer(self):
        if hasattr(bpy.ops.import_scene, "gltf"):
            return True, "operator available"

        enable_errors = []
        try:
            addon_utils.enable("io_scene_gltf2", default_set=True, persistent=True)
        except Exception as exc:
            enable_errors.append(f"addon_utils.enable failed: {exc}")

        if hasattr(bpy.ops.import_scene, "gltf"):
            return True, "enabled via addon_utils"

        try:
            bpy.ops.preferences.addon_enable(module="io_scene_gltf2")
        except Exception as exc:
            enable_errors.append(f"preferences.addon_enable failed: {exc}")

        if hasattr(bpy.ops.import_scene, "gltf"):
            return True, "enabled via preferences"

        return False, "; ".join(enable_errors) if enable_errors else "gltf operator unavailable"

    def _apply_transform_to_objects(self, objects, params, index):
        transform = params.get("transform") or {}
        location = params.get("location")
        translation = transform.get("translation") if isinstance(transform, dict) else None
        rotation = transform.get("rotation") if isinstance(transform, dict) else None
        scale = transform.get("scale") if isinstance(transform, dict) else None

        for obj in objects:
            if isinstance(translation, list) and len(translation) >= 3:
                obj.location = (
                    float(translation[0]),
                    float(translation[1]),
                    float(translation[2]),
                )
            elif isinstance(location, list) and len(location) >= 3:
                obj.location = (
                    float(location[0]),
                    float(location[1]),
                    float(location[2]),
                )
            else:
                # Default layout spread for batch imports without explicit transform.
                obj.location.x += float(index % 3) * 2.8
                obj.location.y += float(index // 3) * -2.8

            if isinstance(rotation, list) and len(rotation) >= 4:
                # Input is [x,y,z,w], Blender quaternion expects [w,x,y,z]
                obj.rotation_mode = "QUATERNION"
                obj.rotation_quaternion = (
                    float(rotation[3]),
                    float(rotation[0]),
                    float(rotation[1]),
                    float(rotation[2]),
                )

            if isinstance(scale, list) and len(scale) >= 3:
                obj.scale = (float(scale[0]), float(scale[1]), float(scale[2]))

    def _import_mesh_with_params(self, params, index=0):
        mesh_url = params.get("mesh_url") or params.get("meshUrl")
        file_path = params.get("file_path") or params.get("filePath")
        name = params.get("name")

        if not mesh_url and not file_path:
            return {
                "status": "error",
                "message": "Missing mesh_url or file_path",
                "details": {"index": index},
            }

        gltf_ready, gltf_detail = self._ensure_gltf_importer()
        if not gltf_ready:
            return {
                "status": "error",
                "message": "glTF importer unavailable (io_scene_gltf2 not enabled)",
                "details": {"index": index, "reason": gltf_detail},
            }

        temp_downloaded = None
        local_path = file_path
        try:
            if not local_path:
                suffix = ".glb"
                if isinstance(mesh_url, str) and mesh_url.lower().endswith(".gltf"):
                    suffix = ".gltf"
                fd, temp_downloaded = tempfile.mkstemp(suffix=suffix)
                os.close(fd)
                urllib.request.urlretrieve(mesh_url, temp_downloaded)
                local_path = temp_downloaded

            existing_names = set(obj.name for obj in bpy.data.objects)
            bpy.ops.import_scene.gltf(filepath=local_path)
            new_objects = [obj for obj in bpy.data.objects if obj.name not in existing_names]

            if not new_objects:
                return {
                    "status": "error",
                    "message": "Import succeeded but no new objects were detected",
                    "details": {"index": index},
                }

            self._apply_transform_to_objects(new_objects, params, index)
            if name:
                try:
                    new_objects[0].name = str(name)
                except Exception:
                    pass

            return {
                "status": "ok",
                "result": {
                    "index": index,
                    "imported_count": len(new_objects),
                    "object_names": [obj.name for obj in new_objects],
                    "gltf_status": gltf_detail,
                },
            }
        except Exception:
            return {
                "status": "error",
                "message": traceback.format_exc(),
                "details": {"index": index},
            }
        finally:
            if temp_downloaded and os.path.exists(temp_downloaded):
                try:
                    os.remove(temp_downloaded)
                except Exception:
                    pass

    def _import_mesh(self, params):
        response = self._import_mesh_with_params(params, index=0)
        if response.get("status") == "ok":
            try:
                bpy.ops.ed.undo_push(message="BlenderGPT import")
            except Exception:
                pass
            if isinstance(response.get("result"), dict):
                response["result"].update(self._build_undo_metadata("import", "Imported model"))
        return response

    def _import_mesh_batch(self, params):
        items = params.get("items", [])
        if not isinstance(items, list) or not items:
            return {"status": "error", "message": "items must be a non-empty list"}

        imported_count = 0
        failed = []
        imported = []

        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                failed.append({"index": idx, "error": "item must be an object"})
                continue
            result = self._import_mesh_with_params(item, index=idx)
            if result.get("status") == "ok":
                imported_count += 1
                imported.append(result.get("result", {}))
            else:
                failed.append(
                    {
                        "index": idx,
                        "name": item.get("name", f"Generated_{idx+1}"),
                        "error": result.get("message", "Import failed"),
                        "details": result.get("details"),
                    }
                )

        response = {
            "status": "ok" if imported_count > 0 else "error",
            "result": {
                "imported_count": imported_count,
                "failed": failed,
                "total": len(items),
                "imported": imported,
            },
        }
        if imported_count > 0:
            try:
                bpy.ops.ed.undo_push(message="BlenderGPT import")
            except Exception:
                pass
            response["result"].update(self._build_undo_metadata("import", "Imported model"))
        return response

    def _execute_code(self, params):
        code = params.get("code", "")
        if not code:
            return {"status": "error", "message": "Missing 'code' parameter"}

        stdout_capture = io.StringIO()
        globals_dict = {
            "__name__": "__main__",
            "bpy": bpy,
        }

        try:
            with redirect_stdout(stdout_capture):
                exec(code, globals_dict, globals_dict)
            bpy.ops.ed.undo_push(message="BlenderGPT script")
        except Exception:
            return {
                "status": "error",
                "message": traceback.format_exc(),
            }

        output = stdout_capture.getvalue().strip()
        if not output:
            output = "Code executed successfully (no output)"
        return {
            "status": "ok",
            "result": output,
            **self._build_undo_metadata("script", "Executed Blender script"),
        }

    def _get_scene_info(self):
        objects = []
        for obj in bpy.data.objects:
            materials = []
            try:
                for slot in obj.material_slots:
                    if slot.material:
                        materials.append(slot.material.name)
            except Exception:
                materials = []

            objects.append(
                {
                    "name": obj.name,
                    "type": obj.type,
                    "location": [float(v) for v in obj.location],
                    "rotation": [float(v) for v in obj.rotation_euler],
                    "scale": [float(v) for v in obj.scale],
                    "materials": materials,
                }
            )

        scene = bpy.context.scene
        return {
            "status": "ok",
            "result": {
                "scene_name": scene.name if scene else "",
                "object_count": len(objects),
                "objects": objects,
                "active_object": bpy.context.active_object.name
                if bpy.context.active_object
                else None,
            },
        }

    def _get_viewport_screenshot(self):
        scene = bpy.context.scene
        if scene is None:
            return {"status": "error", "message": "No active Blender scene"}

        fd, temp_path = tempfile.mkstemp(suffix=".png")
        os.close(fd)

        old_filepath = scene.render.filepath
        old_file_format = scene.render.image_settings.file_format

        try:
            scene.render.filepath = temp_path
            scene.render.image_settings.file_format = "PNG"
            bpy.ops.render.opengl(write_still=True)

            with open(temp_path, "rb") as f:
                encoded = base64.b64encode(f.read()).decode("utf-8")
            return {"status": "ok", "result": encoded}
        except Exception:
            return {"status": "error", "message": traceback.format_exc()}
        finally:
            scene.render.filepath = old_filepath
            scene.render.image_settings.file_format = old_file_format
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass


def _bridge_post_json(server_url, path, payload, timeout=30):
    req = urllib.request.Request(
        f"{server_url}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8") or "{}")


# ---------------------------------------------------------------------------
# Minimal WebSocket client (RFC 6455) used by BlenderGPTWebSocketBridge.
# Text frames only, TLS supported, no compression. Control frames (ping/pong/
# close) are handled internally during recv_text().
# ---------------------------------------------------------------------------

class _WSProtocolError(Exception):
    pass


def _parse_ws_url(url):
    if url.startswith("wss://"):
        use_tls, rest = True, url[6:]
    elif url.startswith("ws://"):
        use_tls, rest = False, url[5:]
    else:
        raise ValueError("Invalid WebSocket URL: " + url)
    if "/" in rest:
        hostport, remainder = rest.split("/", 1)
        path = "/" + remainder
    else:
        hostport, path = rest, "/"
    if ":" in hostport:
        host, port_s = hostport.rsplit(":", 1)
        port = int(port_s)
    else:
        host = hostport
        port = 443 if use_tls else 80
    return host, port, path, use_tls


class MinimalWSClient:
    def __init__(self, url, headers=None, connect_timeout=10.0):
        host, port, path, use_tls = _parse_ws_url(url)
        self._host = host
        self._port = port
        self._sock = socket.create_connection((host, port), timeout=connect_timeout)
        if use_tls:
            ctx = ssl.create_default_context()
            self._sock = ctx.wrap_socket(self._sock, server_hostname=host)
        self._recv_buffer = bytearray()
        self._closed = False
        self._handshake(host, port, path, headers or {})

    def _handshake(self, host, port, path, headers):
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        default_port = (port == 443) or (port == 80)
        host_header = host if default_port else f"{host}:{port}"
        request_lines = [
            f"GET {path} HTTP/1.1",
            f"Host: {host_header}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            "Sec-WebSocket-Version: 13",
            f"Sec-WebSocket-Key: {key}",
        ]
        for k, v in headers.items():
            request_lines.append(f"{k}: {v}")
        self._sock.sendall(("\r\n".join(request_lines) + "\r\n\r\n").encode("ascii"))

        response = bytearray()
        self._sock.settimeout(10.0)
        while b"\r\n\r\n" not in response:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise _WSProtocolError("Handshake closed by peer")
            response += chunk
            if len(response) > 32768:
                raise _WSProtocolError("Handshake response too large")
        header_end = response.index(b"\r\n\r\n")
        header_block = bytes(response[:header_end])
        leftover = bytes(response[header_end + 4:])

        decoded = header_block.decode("ascii", "replace")
        status_line = decoded.split("\r\n", 1)[0]
        if "101" not in status_line:
            raise _WSProtocolError("Unexpected handshake status: " + status_line)
        expected = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()
        ).decode("ascii")
        accept = None
        for line in decoded.split("\r\n")[1:]:
            if ":" in line:
                name, value = line.split(":", 1)
                if name.strip().lower() == "sec-websocket-accept":
                    accept = value.strip()
                    break
        if accept != expected:
            raise _WSProtocolError("Invalid Sec-WebSocket-Accept")
        if leftover:
            self._recv_buffer.extend(leftover)

    def _recv_exact(self, n):
        while len(self._recv_buffer) < n:
            chunk = self._sock.recv(8192)
            if not chunk:
                raise _WSProtocolError("Socket closed during recv")
            self._recv_buffer.extend(chunk)
        out = bytes(self._recv_buffer[:n])
        del self._recv_buffer[:n]
        return out

    def _send_frame(self, opcode, payload):
        if self._closed:
            raise _WSProtocolError("Connection closed")
        header = bytearray()
        header.append(0x80 | (opcode & 0x0F))
        mask_bit = 0x80
        length = len(payload)
        if length < 126:
            header.append(mask_bit | length)
        elif length < (1 << 16):
            header.append(mask_bit | 126)
            header += struct.pack(">H", length)
        else:
            header.append(mask_bit | 127)
            header += struct.pack(">Q", length)
        mask = os.urandom(4)
        header += mask
        masked = bytearray(length)
        for i in range(length):
            masked[i] = payload[i] ^ mask[i & 3]
        self._sock.sendall(bytes(header) + bytes(masked))

    def send_text(self, text):
        self._send_frame(0x1, text.encode("utf-8"))

    def recv_text(self, timeout=None):
        """Return the next text message, handling control frames transparently."""
        self._sock.settimeout(timeout)
        message = bytearray()
        started = False
        while True:
            b1 = self._recv_exact(1)[0]
            fin = bool(b1 & 0x80)
            opcode = b1 & 0x0F
            b2 = self._recv_exact(1)[0]
            masked = bool(b2 & 0x80)
            length = b2 & 0x7F
            if length == 126:
                length = struct.unpack(">H", self._recv_exact(2))[0]
            elif length == 127:
                length = struct.unpack(">Q", self._recv_exact(8))[0]
            mask = self._recv_exact(4) if masked else None
            payload = self._recv_exact(length) if length else b""
            if mask:
                payload = bytes(payload[i] ^ mask[i & 3] for i in range(length))

            if opcode == 0x9:  # ping
                self._send_frame(0xA, payload)
                continue
            if opcode == 0xA:  # pong
                continue
            if opcode == 0x8:  # close
                self._closed = True
                code = struct.unpack(">H", payload[:2])[0] if len(payload) >= 2 else 1000
                try:
                    self._send_frame(0x8, struct.pack(">H", code))
                except Exception:
                    pass
                raise _WSProtocolError(f"Peer closed connection (code={code})")
            if opcode in (0x1, 0x2):
                if started:
                    raise _WSProtocolError("Unexpected new message mid-fragmentation")
                started = True
                message.extend(payload)
            elif opcode == 0x0:  # continuation
                if not started:
                    raise _WSProtocolError("Continuation without start frame")
                message.extend(payload)
            else:
                raise _WSProtocolError(f"Unknown opcode {opcode}")
            if fin:
                return message.decode("utf-8", "replace")

    def close(self, code=1000):
        if self._closed:
            return
        self._closed = True
        try:
            self._send_frame(0x8, struct.pack(">H", code))
        except Exception:
            pass
        try:
            self._sock.close()
        except Exception:
            pass


def _derive_ws_url(server_url):
    override = os.environ.get("BLENDERGPT_WS_URL", "").strip()
    if override:
        return override
    # Local dev: webapp on http://localhost:3000 implies local droplet on 8004.
    lowered = (server_url or "").lower()
    if lowered.startswith("http://localhost") or lowered.startswith("http://127."):
        return "ws://127.0.0.1:8004/bridge/ws"
    return "wss://microservices.blendergpt.org/bridge/ws"


class BlenderGPTRemoteBridge:
    def __init__(self, session_id, session_secret, addon_version):
        self.server_url = BRIDGE_SERVER_URLS[-1].rstrip("/")
        self.session_id = str(session_id or "")
        self.session_secret = str(session_secret or "")
        self.addon_version = addon_version
        self.running = False
        self.thread = None
        self.poll_interval = 1.5
        self.last_error = ""
        self.status_text = "Idle"

    def start(self):
        if self.running:
            return
        self.running = True
        self.status_text = "Connecting"
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        print("[BlenderGPT] Remote bridge starting")

    def stop(self):
        self.running = False
        print("[BlenderGPT] Remote bridge stopped")

    def _post_json(self, path, payload, timeout=30):
        return _bridge_post_json(self.server_url, path, payload, timeout=timeout)

    def _post_result(self, command_id, response):
        try:
            payload = {
                "sessionId": self.session_id,
                "sessionSecret": self.session_secret,
                "commandId": command_id,
            }
            if isinstance(response, dict) and response.get("status") == "error":
                payload.update(
                    {
                        "status": "error",
                        "error": str(response.get("message") or "Unknown Blender error"),
                    }
                )
            else:
                payload.update(
                    {
                        "status": "ok",
                        "result": response,
                    }
                )
            self._post_json("/api/assistant/blender/respond", payload, timeout=30)
        except Exception as exc:
            self.last_error = str(exc)
            self.status_text = f"Response failed: {exc}"

    def _run_command(self, command):
        task = CommandTask(command.get("commandType"), command.get("params") or {})
        server = _get_command_server()
        if server is None:
            return {"status": "error", "message": "Blender command server unavailable"}
        server.command_queue.put(task)
        if not task.done.wait(timeout=60):
            return {
                "status": "error",
                "message": "Command timed out in Blender main thread",
            }
        return task.response

    def _run_loop(self):
        if not self.session_id or not self.session_secret:
            self.status_text = "Not signed in"
            self.last_error = "Missing session credentials"
            self.running = False
            return

        while self.running:
            try:
                payload = self._post_json(
                    "/api/assistant/blender/poll",
                    {
                        "sessionId": self.session_id,
                        "sessionSecret": self.session_secret,
                    },
                    timeout=max(10, int(self.poll_interval) + 10),
                )
                if not payload.get("ok"):
                    raise RuntimeError(str(payload.get("error") or "Remote poll failed"))

                command = payload.get("command")
                self.status_text = "Connected"
                self.last_error = ""
                if not command:
                    time.sleep(self.poll_interval)
                    continue

                response = self._run_command(command)
                self._post_result(str(command.get("commandId") or ""), response)
            except Exception as exc:
                self.last_error = str(exc)
                self.status_text = "Connection lost"
                time.sleep(3.0)


class BlenderGPTWebSocketBridge:
    """Persistent WebSocket to the droplet. Commands are pushed; results flow
    back over the same socket. Replaces the polling BlenderGPTRemoteBridge when
    the droplet's /bridge/ws endpoint is reachable."""

    def __init__(self, session_id, session_secret, addon_version, ws_url):
        self.session_id = str(session_id or "")
        self.session_secret = str(session_secret or "")
        self.addon_version = addon_version
        self.ws_url = ws_url
        self.running = False
        self.thread = None
        self.status_text = "Idle"
        self.last_error = ""
        self._ws = None
        self._ws_lock = threading.Lock()
        self.fatal_auth_failure = False
        self.ever_connected = False

    def start(self):
        if self.running:
            return
        self.running = True
        self.status_text = "Connecting"
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        print("[BlenderGPT] WS bridge starting url=" + self.ws_url)

    def stop(self):
        self.running = False
        with self._ws_lock:
            ws = self._ws
            self._ws = None
        if ws:
            try:
                ws.close()
            except Exception:
                pass
        print("[BlenderGPT] WS bridge stopped")

    def _run_loop(self):
        if not self.session_id or not self.session_secret:
            self.status_text = "Not signed in"
            self.last_error = "Missing session credentials"
            self.running = False
            return

        backoff = 1.0
        while self.running:
            try:
                ws = MinimalWSClient(self.ws_url, connect_timeout=10.0)
            except Exception as exc:
                self.last_error = "Connect failed: " + str(exc)
                self.status_text = "Reconnecting"
                if not self.running:
                    return
                time.sleep(backoff)
                backoff = min(backoff * 2, 30.0)
                continue

            try:
                ws.send_text(json.dumps({
                    "kind": "hello",
                    "sessionId": self.session_id,
                    "sessionSecret": self.session_secret,
                    "addonVersion": self.addon_version,
                }))
                auth_raw = ws.recv_text(timeout=10.0)
                auth = json.loads(auth_raw or "{}")
                if auth.get("kind") == "auth_error":
                    self.fatal_auth_failure = True
                    self.status_text = "Sign-in invalid"
                    self.last_error = str(auth.get("error") or "auth_error")
                    try:
                        ws.close()
                    except Exception:
                        pass
                    return
                if auth.get("kind") != "auth_ok":
                    raise RuntimeError("Unexpected handshake: " + (auth_raw or ""))

                with self._ws_lock:
                    self._ws = ws
                self.ever_connected = True
                self.status_text = "Connected"
                self.last_error = ""
                backoff = 1.0
                self._handle_frames(ws)
            except Exception as exc:
                self.last_error = str(exc)
                self.status_text = "Reconnecting"
            finally:
                with self._ws_lock:
                    if self._ws is ws:
                        self._ws = None
                try:
                    ws.close()
                except Exception:
                    pass

            if not self.running:
                return
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)

    def _handle_frames(self, ws):
        # Droplet sends app-level {"kind":"ping"} every 25s; 40s timeout gives
        # a generous margin before we assume the connection is dead.
        while self.running:
            raw = ws.recv_text(timeout=40.0)
            if not raw:
                continue
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                continue
            kind = frame.get("kind")
            if kind == "command":
                response = self._run_command({
                    "commandType": frame.get("commandType"),
                    "params": frame.get("params") or {},
                })
                payload = {
                    "kind": "result",
                    "commandId": str(frame.get("commandId") or ""),
                }
                if isinstance(response, dict) and response.get("status") == "error":
                    payload["status"] = "error"
                    payload["error"] = str(response.get("message") or "Unknown Blender error")
                else:
                    payload["status"] = "ok"
                    payload["result"] = response
                ws.send_text(json.dumps(payload))
            elif kind == "ping":
                ws.send_text(json.dumps({"kind": "pong"}))
            elif kind in ("pong", "auth_ok"):
                pass
            elif kind == "auth_error":
                self.fatal_auth_failure = True
                self.status_text = "Sign-in invalid"
                return

    def _run_command(self, command):
        task = CommandTask(command.get("commandType"), command.get("params") or {})
        server = _get_command_server()
        if server is None:
            return {"status": "error", "message": "Blender command server unavailable"}
        server.command_queue.put(task)
        if not task.done.wait(timeout=60):
            return {
                "status": "error",
                "message": "Command timed out in Blender main thread",
            }
        return task.response


class BlenderGPTSignIn:
    """Browser-based sign-in. Opens /addon/pair in the user's browser and polls
    until the webapp confirms the request, then stores the resulting session."""

    def __init__(self, addon_version):
        self.addon_version = addon_version
        self.server_url = ""
        self.state_token = ""
        self.pair_url = ""
        self.status = "idle"  # idle | waiting | success | expired | error
        self.error = ""
        self.running = False
        self.thread = None

    def start(self):
        if self.running:
            return

        errors = []
        for candidate_url in BRIDGE_SERVER_URLS:
            server_url = candidate_url.rstrip("/")
            try:
                payload = _bridge_post_json(
                    server_url,
                    "/api/assistant/blender/auth/start",
                    {"addonVersion": self.addon_version},
                    timeout=20,
                )
                if payload.get("ok"):
                    self.server_url = server_url
                    self.state_token = str(payload.get("stateToken") or "")
                    self.pair_url = str(payload.get("pairUrl") or "")
                    break
                errors.append(f"{server_url}: {payload.get('error') or 'start failed'}")
            except Exception as exc:
                errors.append(f"{server_url}: {exc}")

        if not self.state_token or not self.pair_url:
            self.status = "error"
            self.error = " | ".join(errors) or "Couldn't reach BlenderGPT"
            return

        # Browser open is best-effort. Link is always shown in the UI as fallback.
        try:
            webbrowser.open(self.pair_url)
        except Exception:
            pass

        self.status = "waiting"
        self.error = ""
        self.running = True
        self.thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.thread.start()
        bpy.app.timers.register(_tick_sign_in_redraw, first_interval=0.5)
        print("[BlenderGPT] Sign-in started")

    def cancel(self):
        self.running = False
        self.status = "idle"
        self.state_token = ""
        self.pair_url = ""
        self.error = ""

    def _poll_loop(self):
        deadline = time.time() + 10 * 60
        poll_interval = 2.0
        encoded_state = urllib.parse.quote(self.state_token, safe="")
        while self.running and time.time() < deadline:
            try:
                url = f"{self.server_url}/api/assistant/blender/auth/poll?state={encoded_state}"
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=15) as response:
                    payload = json.loads(response.read().decode("utf-8") or "{}")

                status = str(payload.get("status") or "pending")
                if status == "claimed":
                    self._on_claimed(
                        str(payload.get("sessionId") or ""),
                        str(payload.get("sessionSecret") or ""),
                        max(1.0, float(payload.get("pollIntervalMs", 1500)) / 1000.0),
                    )
                    return
                if status in ("expired", "revoked"):
                    self.running = False
                    self.status = "expired"
                    self.error = f"Sign-in {status}. Try again."
                    return
                # pending | confirmed — keep waiting
            except Exception as exc:
                self.error = str(exc)

            time.sleep(poll_interval)

        if self.running:
            self.status = "expired"
            self.error = "Sign-in timed out. Try again."
        self.running = False

    def _on_claimed(self, session_id, session_secret, poll_interval):
        self.running = False
        self.status = "success"
        self.error = ""
        _set_remote_session_values(session_id, session_secret, server_url=self.server_url)
        _start_ws_bridge_with_fallback(session_id, session_secret, self.server_url, poll_interval)
        _set_running_flag_for_all_scenes(True)


SERVER = None
CLOUD_BRIDGE = None
SIGN_IN = None


def _tick_sign_in_redraw():
    """Force UI repaints while sign-in is active so the status updates are visible."""
    if not SIGN_IN or (not SIGN_IN.running and SIGN_IN.status != "success"):
        return None  # unregister timer
    try:
        for wm in bpy.data.window_managers:
            for window in wm.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
    except Exception:
        pass
    return 0.75


def _get_scenes_safely():
    scenes = []
    try:
        data = getattr(bpy, "data", None)
        if data is not None:
            data_scenes = getattr(data, "scenes", None)
            if data_scenes is not None:
                scenes.extend(list(data_scenes))
    except Exception:
        pass

    if not scenes:
        try:
            scene = getattr(bpy.context, "scene", None)
            if scene is not None:
                scenes.append(scene)
        except Exception:
            pass

    return scenes


def _sync_scene_settings_from_preferences():
    prefs = _get_addon_preferences()
    if not prefs:
        return
    for scene in _get_scenes_safely():
        try:
            settings = scene.blendergpt_settings
            settings.session_id = prefs.session_id
            settings.session_secret = prefs.session_secret
            settings.server_url = getattr(prefs, "server_url", "") or ""
        except Exception:
            pass


def _set_remote_session_values(session_id="", session_secret="", server_url=None):
    prefs = _get_addon_preferences()
    if prefs:
        try:
            prefs.session_id = session_id
            prefs.session_secret = session_secret
            if server_url is not None:
                prefs.server_url = server_url
        except Exception:
            pass
    for scene in _get_scenes_safely():
        try:
            settings = scene.blendergpt_settings
            settings.session_id = session_id
            settings.session_secret = session_secret
            if server_url is not None:
                settings.server_url = server_url
        except Exception:
            pass


def _get_primary_settings():
    prefs = _get_addon_preferences()
    if prefs:
        return prefs
    try:
        scene = bpy.context.scene
        if scene and scene.blendergpt_settings:
            return scene.blendergpt_settings
    except Exception:
        pass
    return None


def _set_running_flag_for_all_scenes(is_running: bool):
    for scene in _get_scenes_safely():
        try:
            if hasattr(scene, "blendergpt_settings") and scene.blendergpt_settings:
                scene.blendergpt_settings.is_running = is_running
        except Exception:
            pass


def _get_command_server():
    global SERVER
    if SERVER is None:
        SERVER = BlenderGPTServer(host="127.0.0.1", port=9876)
    SERVER.ensure_command_processor()
    return SERVER


def _start_local_server(port):
    global SERVER, CLOUD_BRIDGE
    if CLOUD_BRIDGE:
        CLOUD_BRIDGE.stop()
        CLOUD_BRIDGE = None
    if SERVER and SERVER.running:
        _set_running_flag_for_all_scenes(True)
        return
    SERVER = BlenderGPTServer(host="127.0.0.1", port=port)
    SERVER.start()
    _set_running_flag_for_all_scenes(True)


def _stop_local_server():
    global SERVER
    if SERVER:
        SERVER.stop()
        SERVER = None
    _set_running_flag_for_all_scenes(False)


def _start_ws_bridge_with_fallback(session_id, session_secret, server_url, poll_interval=1.5):
    """Start the WebSocket bridge; if it hasn't connected within 15s, transparently
    swap in the legacy polling bridge so the user still gets a connection."""
    global CLOUD_BRIDGE
    _stop_local_server()
    if CLOUD_BRIDGE:
        try:
            CLOUD_BRIDGE.stop()
        except Exception:
            pass
        CLOUD_BRIDGE = None

    addon_version = ".".join(str(v) for v in bl_info["version"])
    ws_url = _derive_ws_url(server_url or "")
    ws_bridge = BlenderGPTWebSocketBridge(session_id, session_secret, addon_version, ws_url)
    CLOUD_BRIDGE = ws_bridge
    ws_bridge.start()

    def _ws_fallback_watchdog():
        global CLOUD_BRIDGE
        bridge = CLOUD_BRIDGE
        if bridge is not ws_bridge:
            return  # already replaced by another flow
        if ws_bridge.fatal_auth_failure or ws_bridge.ever_connected:
            return
        print("[BlenderGPT] WS didn't connect within 15s; falling back to polling")
        try:
            ws_bridge.stop()
        except Exception:
            pass
        polling = BlenderGPTRemoteBridge(session_id, session_secret, addon_version)
        if server_url:
            polling.server_url = server_url
        polling.poll_interval = poll_interval
        CLOUD_BRIDGE = polling
        polling.start()

    threading.Timer(15.0, _ws_fallback_watchdog).start()


def _start_remote_bridge(settings):
    session_id = str(settings.session_id or "")
    session_secret = str(settings.session_secret or "")
    server_url = str(getattr(settings, "server_url", "") or "")
    _start_ws_bridge_with_fallback(session_id, session_secret, server_url)
    _set_running_flag_for_all_scenes(True)


def _stop_remote_bridge(clear_session=False):
    global CLOUD_BRIDGE
    if CLOUD_BRIDGE:
        CLOUD_BRIDGE.stop()
        CLOUD_BRIDGE = None
    if clear_session:
        _set_remote_session_values("", "")
    _set_running_flag_for_all_scenes(False)


class BLENDERGPT_OT_start_server(bpy.types.Operator):
    bl_idname = "blendergpt.start_server"
    bl_label = "Start BlenderGPT Server"

    def execute(self, context):
        _sync_scene_settings_from_preferences()
        settings = _get_primary_settings()
        if settings is None:
            self.report({"ERROR"}, "BlenderGPT settings are unavailable")
            return {"CANCELLED"}
        _start_local_server(settings.port)
        return {"FINISHED"}


class BLENDERGPT_OT_stop_server(bpy.types.Operator):
    bl_idname = "blendergpt.stop_server"
    bl_label = "Stop BlenderGPT Server"

    def execute(self, context):
        _stop_local_server()
        return {"FINISHED"}


class BLENDERGPT_OT_sign_in(bpy.types.Operator):
    bl_idname = "blendergpt.sign_in"
    bl_label = "Sign into BlenderGPT"
    bl_description = "Opens your browser to sign into BlenderGPT"

    def execute(self, context):
        global SIGN_IN
        if SIGN_IN and SIGN_IN.running:
            return {"CANCELLED"}
        SIGN_IN = BlenderGPTSignIn(".".join(str(v) for v in bl_info["version"]))
        SIGN_IN.start()
        if SIGN_IN.status == "error":
            self.report({"ERROR"}, SIGN_IN.error or "Couldn't start sign-in")
            return {"CANCELLED"}
        return {"FINISHED"}


class BLENDERGPT_OT_cancel_sign_in(bpy.types.Operator):
    bl_idname = "blendergpt.cancel_sign_in"
    bl_label = "Cancel sign-in"

    def execute(self, context):
        global SIGN_IN
        if SIGN_IN:
            SIGN_IN.cancel()
            SIGN_IN = None
        return {"FINISHED"}


class BLENDERGPT_OT_copy_sign_in_link(bpy.types.Operator):
    bl_idname = "blendergpt.copy_sign_in_link"
    bl_label = "Copy sign-in link"
    bl_description = "Copy the sign-in URL to paste into any browser"

    def execute(self, context):
        if not SIGN_IN or not SIGN_IN.pair_url:
            self.report({"ERROR"}, "No sign-in in progress")
            return {"CANCELLED"}
        context.window_manager.clipboard = SIGN_IN.pair_url
        self.report({"INFO"}, "Sign-in link copied")
        return {"FINISHED"}


class BLENDERGPT_OT_sign_out(bpy.types.Operator):
    bl_idname = "blendergpt.sign_out"
    bl_label = "Sign out"

    def execute(self, context):
        global SIGN_IN
        if SIGN_IN:
            SIGN_IN.cancel()
            SIGN_IN = None
        _stop_remote_bridge(clear_session=True)
        return {"FINISHED"}


class BLENDERGPT_PG_settings(bpy.types.PropertyGroup):
    session_id: bpy.props.StringProperty(name="Session ID", default="")
    session_secret: bpy.props.StringProperty(name="Session Secret", default="")
    server_url: bpy.props.StringProperty(name="Server URL", default="")
    is_running: bpy.props.BoolProperty(name="Running", default=False)


class BLENDERGPT_AP_preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    session_id: bpy.props.StringProperty(name="Session ID", default="")
    session_secret: bpy.props.StringProperty(name="Session Secret", default="")
    server_url: bpy.props.StringProperty(name="Server URL", default="")

    def draw(self, context):
        _draw_connection_ui(self.layout, self, is_preferences=True)


class BLENDERGPT_PT_panel(bpy.types.Panel):
    bl_label = "BlenderGPT Addon"
    bl_idname = "BLENDERGPT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlenderGPT"

    def draw(self, context):
        settings = context.scene.blendergpt_settings
        settings.is_running = bool(CLOUD_BRIDGE and CLOUD_BRIDGE.running)
        _draw_connection_ui(self.layout, settings, is_preferences=False)


def _draw_connection_ui(layout, settings, is_preferences):
    signed_in = bool(CLOUD_BRIDGE and CLOUD_BRIDGE.running) or bool(
        settings.session_id and settings.session_secret
    )
    signing_in = bool(SIGN_IN and SIGN_IN.running)
    status_text, status_icon = _connection_status(settings)

    container = layout.box() if is_preferences else layout
    if is_preferences:
        container.label(text="Connect BlenderGPT")
    else:
        container.label(text="Connection is managed in Add-on Preferences.")
    container.label(text=f"Status: {status_text}", icon=status_icon)

    if signing_in and SIGN_IN:
        container.label(text="Waiting for you to finish in the browser…", icon="TIME")
        if SIGN_IN.pair_url:
            col = container.column(align=True)
            col.label(text="Didn't open? Use this link:")
            col.operator("wm.url_open", text="Open sign-in page", icon="URL").url = SIGN_IN.pair_url
            col.operator("blendergpt.copy_sign_in_link", icon="COPYDOWN")
        container.operator("blendergpt.cancel_sign_in", icon="X")
    elif signed_in:
        container.operator("blendergpt.sign_out", icon="UNLINKED")
    else:
        container.operator("blendergpt.sign_in", icon="URL")

    error_source = ""
    if SIGN_IN and SIGN_IN.status in ("error", "expired") and SIGN_IN.error:
        error_source = SIGN_IN.error
    elif CLOUD_BRIDGE and CLOUD_BRIDGE.last_error:
        error_source = CLOUD_BRIDGE.last_error
    for line in _bridge_error_lines(error_source):
        container.label(text=line, icon="ERROR")

    if is_preferences:
        container.label(text="Can't connect? Reach us at hey@blendergpt.org")


def _connection_status(settings):
    if SIGN_IN and SIGN_IN.running:
        return "Signing in…", "TIME"
    if CLOUD_BRIDGE and CLOUD_BRIDGE.running:
        text = "Connected" if "Connected" in CLOUD_BRIDGE.status_text else CLOUD_BRIDGE.status_text
        return text, "CHECKMARK" if text == "Connected" else "TIME"
    if settings.session_id and settings.session_secret:
        return "Connected", "CHECKMARK"
    return "Not connected", "UNLINKED"


classes = (
    BLENDERGPT_OT_sign_in,
    BLENDERGPT_OT_cancel_sign_in,
    BLENDERGPT_OT_copy_sign_in_link,
    BLENDERGPT_OT_sign_out,
    BLENDERGPT_AP_preferences,
    BLENDERGPT_PG_settings,
    BLENDERGPT_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.blendergpt_settings = bpy.props.PointerProperty(
        type=BLENDERGPT_PG_settings
    )
    try:
        _sync_scene_settings_from_preferences()
        settings = _get_primary_settings()
        if settings and str(settings.session_id or "").strip() and str(settings.session_secret or "").strip():
            _start_remote_bridge(settings)
    except Exception:
        pass


def unregister():
    _stop_remote_bridge(clear_session=False)
    _stop_local_server()
    _set_running_flag_for_all_scenes(False)
    if hasattr(bpy.types.Scene, "blendergpt_settings"):
        del bpy.types.Scene.blendergpt_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
